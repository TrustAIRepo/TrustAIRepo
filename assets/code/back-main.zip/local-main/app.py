from flask import Flask, request, jsonify
from flask_cors import CORS
from sentence_transformers import SentenceTransformer


app = Flask(__name__)

CORS(app)  #habilitar CORS
# Cargar el modelo
model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')

@app.route('/get_embedding', methods=['POST'])
def get_embedding():
    data = request.json
    text = data.get('text', '')

    if not text:
        return jsonify({'error': 'No text provided'}), 400

    # Obtener el embedding del texto
    embedding = model.encode([text], normalize_embeddings=True)

    return jsonify({'embedding': embedding.tolist()})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
