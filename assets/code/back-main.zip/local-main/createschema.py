import requests
import json

# URL de la API de Weaviate
weaviate_url = "http://50.85.209.27:8081/v1/schema"

# Esquema para la clase Chunk con "Bring Your Own Vectors"
schema_chunk = {
    "class": "Chunk",
    "vectorizer": "none",  # No generará vectores automáticamente
    "vectorIndexConfig": {
        "distance": "cosine",      # Se utilizará la similitud coseno
        "M": 16,                   # Número de conexiones en HNSW (valor por defecto: 16)
        "efConstruction": 128       # Parámetro de construcción del índice HNSW (valor por defecto: 128)
    },
    "properties": [
        {"name": "content", "dataType": ["text"]},
        {"name": "pageNumber", "dataType": ["int"]},
        {"name": "embeddingModel", "dataType": ["text"]},
        {"name": "embeddingDate", "dataType": ["date"]},
        {"name": "title", "dataType": ["text"]},
        {"name": "author", "dataType": ["text"]},
        {"name": "publicationDate", "dataType": ["date"]},
        {"name": "keywords", "dataType": ["text"]},
        {"name": "identifier", "dataType": ["text"]},
        {"name": "documentType", "dataType": ["text"]},
        {"name": "language", "dataType": ["text"]},
        {"name": "rights", "dataType": ["text"]}
    ]
}

# Encabezados para la solicitud
headers = {"Content-Type": "application/json"}

# Realizar la solicitud POST para crear el esquema de la clase Chunk
response = requests.post(weaviate_url, headers=headers, json=schema_chunk)

if response.status_code == 200:
    print(" Esquema de la clase Chunk creado correctamente.")
    print(json.dumps(response.json(), indent=2))
else:
    print(f" Error al crear el esquema: {response.status_code}")
    print(response.text)
