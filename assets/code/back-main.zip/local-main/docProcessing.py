import os
import requests
import json
from sentence_transformers import SentenceTransformer
import spacy
import re
from datetime import datetime
import weaviate

# URL del servidor de Weaviate
weaviate_url = "http://50.85.209.27:8081"  # Sin "/v1/objects" ya que usamos el cliente oficial

# Cargar el modelo NLP de spaCy
nlp = spacy.load("en_core_web_sm")

# Conectar con Weaviate
client = weaviate.Client("http://50.85.209.27:8081")

def extract_metadata_doc(text):
    """ Extrae metadatos estructurados de un documento de texto """
    doc = nlp(text)

    metadata_doc = {
        "title": None,
        "author": None,
        "publicationDate": None,
        "keywords": None,
        "identifier": None,
        "documentType": "article",
        "language": "English",
        "publisher": None,
        "rights": None,
    }

    title_match = re.search(r"Title\n(.+)", text)
    if title_match:
        metadata_doc["title"] = title_match.group(1).strip()

    authors_section = re.search(r"Authors\n(.+?)\nKeywords", text, re.DOTALL)
    if authors_section:
        metadata_doc["author"] = authors_section.group(1).strip()

    publication_date_match = re.search(r"Publication Date\n(.+)", text)
    if publication_date_match:
        date_str = publication_date_match.group(1).strip()
        metadata_doc["publicationDate"] = datetime.strptime(date_str, "%B %d, %Y").date().strftime("%Y-%m-%dT%H:%M:%SZ")

    keywords_section = re.search(r"Keywords\n(.+?)\nSummary", text, re.DOTALL)
    if keywords_section:
        metadata_doc["keywords"] = keywords_section.group(1).strip()

    identifier_match = re.search(r"DOI\n(.+)", text)
    if identifier_match:
        metadata_doc["identifier"] = identifier_match.group(1).strip()

    rights_section = re.search(r"Rights and Licenses\n(.+)", text, re.DOTALL)
    if rights_section:
        metadata_doc["rights"] = rights_section.group(1).strip()

    content = None
    content_section = re.search(r"Introduction\n(.+?)\nConclusion", text, re.DOTALL)
    if content_section:
        content = content_section.group(1).strip()

    return metadata_doc, content

def split_into_chunks(text, metadata_doc, min_words=100, max_words=150):
    """ Divide un documento en chunks según un rango de palabras """
    words = text.split()
    chunks = []
    metadata_chunk = {
        "content": None,
        "pageNumber": 1,
        "embeddingModel": "all-MiniLM-L6-v2",
        "embeddingDate": datetime.today().strftime("%Y-%m-%dT%H:%M:%SZ"),
        "title": metadata_doc["title"],
        "author": metadata_doc["author"],
        "publicationDate": metadata_doc["publicationDate"],
        "keywords": metadata_doc["keywords"],
        "identifier": metadata_doc["identifier"],
        "documentType": metadata_doc["documentType"],
        "language": metadata_doc["language"],
        "rights": metadata_doc["rights"],
    }
    current_chunk = []
   for word in words:
        current_chunk.append(word)
        if len(current_chunk) >= max_words:
            chunks.append(' '.join(current_chunk))
            current_chunk = []
    if len(current_chunk) >= min_words:
        chunks.append(' '.join(current_chunk))

    return chunks, metadata_chunk

def generate_embeddings(chunks, model_name='all-MiniLM-L6-v2'):
    """ Genera embeddings para cada chunk de texto """
    model = SentenceTransformer(model_name)
    embeddings = model.encode(chunks, normalize_embeddings=True, show_progress_bar=True)
    return embeddings

def read_file(file_path):
    """ Lee un archivo de texto y devuelve su contenido """
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.read()

def process_directory(directory_path):
    """ Procesa los archivos en el directorio, extrae información y los almacena en Weaviate """
    txt_files = [f for f in os.listdir(directory_path) if f.endswith('.txt')]

    for file_name in txt_files:
        file_path = os.path.join(directory_path, file_name)
        text = read_file(file_path)
        metadata_doc, content = extract_metadata_doc(text)

        if not content:
            print(f" No se encontró contenido en el archivo: {file_name}")
            continue

        chunks, metadata_chunk = split_into_chunks(content, metadata_doc)
        embeddings = generate_embeddings(chunks)
        for chunk, embedding in zip(chunks, embeddings):
            # Crear datos del chunk sin incluir "vector" en properties
            chunk_data = {
                "content": chunk,
                "pageNumber": metadata_chunk["pageNumber"],
                "embeddingModel": metadata_chunk["embeddingModel"],
                "embeddingDate": metadata_chunk["embeddingDate"],
                "title": metadata_chunk["title"],
                "author": metadata_chunk["author"],
                "publicationDate": metadata_chunk["publicationDate"],
                "keywords": metadata_chunk["keywords"],
                "identifier": metadata_chunk["identifier"],
                "documentType": metadata_chunk["documentType"],
                "language": metadata_chunk["language"],
                "rights": metadata_chunk["rights"],
            }

            # Insertar en Weaviate con el vector interno
            client.data_object.create(
                data_object=chunk_data,
                class_name="Chunk",
                vector=embedding.tolist()  #  Pasar el vector en el parámetro interno
            )

            print(f" Chunk insertado correctamente en {file_name}")

# Obtener la ruta del directorio donde se encuentra el script
current_dir = os.path.dirname(os.path.abspath(__file__))

# Definir la ruta al directorio corpus
directory_path = os.path.join(current_dir, 'corpus')

# Procesar los archivos .txt en el directorio corpus
process_directory(directory_path)
