from flask import Flask, request, render_template_string, redirect, url_for, session
from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from openai import OpenAI
import logging
import weaviate
import requests
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient
import markdown
from datetime import datetime


app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'

# Configuración de logging
logging.basicConfig(level=logging.ERROR)
logger = logging.getLogger(__name__)

# URL del Key Vault
key_vault_url = "https://almacenrag.vault.azure.net"
secret_name = "openai"

# Autenticación (usa DefaultAzureCredential, compatible con múltiples métodos de autenticación)
credential = DefaultAzureCredential()

# Crear cliente del Key Vault
client_secret = SecretClient(vault_url=key_vault_url, credential=credential)

# Obtener el secreto
try:
    secret = client_secret.get_secret(secret_name)
    print(f"El valor del secreto '{secret_name}' es: {secret.value}")
except Exception as e:
    print(f"Error al obtener el secreto: {e}")

client = OpenAI(api_key=secret.value)

def generar_embedding2(pregunta):
    
    url = "http://50.85.209.27:8080/get_embedding"
    data = {"text": pregunta}
    headers = {"Content-Type": "application/json"}

    response = requests.post(url, json=data, headers=headers)

    if response.status_code == 200:
            embedding = response.json().get('embedding')
            flat_embedding = [item for sublist in embedding for item in sublist]
            return flat_embedding
    else:
            raise Exception(f"Error: {response.status_code}, {response.text}")
        
# Configuración de la base de datos
DATABASE_URL = 'sqlite:///users.db'
engine = create_engine(DATABASE_URL)
Base = declarative_base()
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
db_session = SessionLocal()

# Modelo de usuario
class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)
    password = Column(String)

Base.metadata.create_all(bind=engine)

# Usuarios predefinidos
if not db_session.query(User).filter_by(username='Mario').first():
    db_session.add(User(username='Mario', password='CxeyMH_-jA3_RiY'))
if not db_session.query(User).filter_by(username='Blanca').first():
    db_session.add(User(username='Blanca', password='CxeyMH_-jA3_RiY'))
db_session.commit()

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = db_session.query(User).filter_by(username=username).first()
        if user and user.password == password:
            session['username'] = username
            return redirect(url_for('index'))
    return render_template_string('''
        <!doctype html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Login</title>
        </head>
        <body>
            <form method="POST">
                <input type="text" name="username" placeholder="Username" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit">Login</button>
            </form>
        </body>
        </html>''')

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))

@app.route('/', methods=['GET', 'POST'])
def index():
    if 'username' not in session:
        return redirect(url_for('login'))
    answer1 = None
    answer2 = None
    error = None
    question = ""

    # Mensaje del sistema con instrucciones detalladas y secuenciales

    system_message = (
        "You are a highly reliable assistant. Follow the instructions below precisely to generate your final answer:\n\n"
        "Before constructing your final answer, perform the following internal processes without outputting any details:\n"
        "   - Analyze the input prompt (question and context) for compliance with ethical principles (Beneficence, Non-maleficence—including privacy issues, Justice—including discrimination issues, Autonomy, Explicability, Lawfulness, and ethical use of technology). In doing so, ensure that any content involving privacy-sensitive information (such as personal identifiers, phone numbers, IDs, etc.) is masked, removed, or replaced with generic placeholders, and that any inappropriate or inaccurate gender representations (for example, attributing 'female' or 'male' to entities that are scientifically non-gendered) are corrected or omitted. If any such modifications are necessary, make sure to record them for inclusion in the Trustworthiness Engine feedback. Do not leave any privacy-sensitive data unmodified.\n"
        "   - Extract all relevant references from the provided context, ensuring that duplicates are removed. Do not assign final reference numbers at this stage.\n"
        "   - Generate the answer text with in-text citations as they naturally appear (using their original identifiers), and include the __References:__ section containing all extracted references, ensuring that each reference entry includes all its provided details, particularly the 'Rights' field when available.\n"
        "   - After the answer text is fully generated, perform a final mapping process: Scan the entire final text (including the answer body and the __References:__ section) to detect the order in which each unique reference is first cited. Build a mapping that assigns a new sequential number starting from 1 to each reference, then replace all in-text citations and update the __References:__ section accordingly. This ensures that only the references cited in the text appear and that their numbering is sequential with no gaps. **During this process, verify that the 'Rights' field for each reference is preserved and included exactly as provided in the context.**\n\n"
        "Now, construct your final answer using the following format:\n"
        "   1. Start with the note: \"This content was generated with artificial intelligence. Please note that the information provided is based on the latest available data as of 31-12-9999.\"\n"
        "   2. Provide the answer text, integrating citations using the format [n] (where [n] is the reference number). Ensure that each citation is placed directly next to the portion of text it supports. The numbering of references must be sequential (1, 2, 3, …) with no gaps.\n"
        "   3. Include the sentence: \"If you have any further questions or would like to delve deeper into the topic, feel free to ask.\"\n"
        "   4. Append a section with the header __References:__ (using Markdown for underlining) followed by a complete, sequential list of all references that are explicitly cited in the answer text. Do not include any references that were not part of the context provided in the prompt. Each reference must include its number, details (including the 'Rights' field when provided in the context), and be formatted in Markdown (e.g., reference titles in *italics*).\n"
        "   5. Append a section with the header __Trustworthiness engine:__ (using Markdown for underlining). In this section, provide a detailed explanation of all corrections, omissions, or modifications made during your internal trustworthiness analysis. In particular, if any privacy-sensitive information (e.g., phone numbers, IDs) was detected, explicitly state how it was modified, and do not output \"No modifications were necessary\" if such data is present. Similarly, describe any modifications made to correct inappropriate gender representations or other ethical issues.\n\n"
        "Important formatting instructions:\n"
        "   - Use actual newline characters (\\n) for line breaks instead of HTML tags.\n"
        "   - Use Markdown syntax (e.g., *italic text*) to render text in italics.\n\n"
        "Only output the final answer following the format above, without disclosing any details of the internal processes."
    )

 
    if request.method == 'POST':
        question = request.form['question']
        
        # Generar el embedding de la pregunta
        embedding = generar_embedding2(question)
        logger.info("Embedding Generado")
        if embedding:
            
            # Conectar a la instancia de Weaviate
            bbddclient = weaviate.Client("http://50.85.209.27:8081", additional_headers={"Connection":"close"})
            # Realizar una consulta a Weaviate para obtener los chunks más cercanos
            logger.info("Lanzamos consulta a Weaviate")
            nearvector = {"vector": embedding, "certainty": 0.7 }
            result = bbddclient.query.get("Chunk", ["content", "pageNumber", "embeddingModel", "embeddingDate", "title", "author", "publicationDate", "identifier", "documentType", "language", "rights"]).with_near_vector(nearvector).with_limit(10).do()
            logger.info("Recibimos repuesta de weaviate e iniciamos la generación del prompt")          
            # Construir la variable prompt
            prompt = f"Question: {question}\n\nItems of relevant context:\n"
            
            chunks = result.get("data", {}).get("Get", {}).get("Chunk", [])
            chunkNumber=1

            # Iterar sobre los chunks y extraer información
            for chunk in chunks:
                content = chunk.get("content")
                page_number = chunk.get("pageNumber")
                embedding_date = chunk.get("embeddingDate")
                title = chunk.get("title")
                author = chunk.get("author")
                publication_date = chunk.get("publicationDate")
                rights = chunk.get("rights")

                prompt += f"- Relevant context {chunkNumber} : {content} (Page: {page_number}, Title: {title}, Author: {author}, Publication Date: {publication_date}, Embedding Date: {embedding_date}, Rights: {rights})\n"
                chunkNumber = chunkNumber + 1
                logger.info("Prompt Construido")
        
        # Enviar el prompt al modelo de OpenAI
        logger.info("Llamamos a openAI con la llamada standard")
        response1 = client.chat.completions.create(
                model="gpt-4o-mini",
                store=False,
                messages=[
                    {"role": "system", "content": "You are a useful assistant that adheres to ethical principles and communicate in a formal and friendly tone in the same language of the question."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=600,
                n=1,
                temperature=0.3
         )
         
   	    # Enviar el prompt al modelo de OpenAI
        logger.info("Llamamos a openAI con la llamada Trust")
        response2 = client.chat.completions.create(
                model="gpt-4o-mini",
                store=False,
                messages=[
                    {  "role": "system",   "content": system_message},
                    {"role": "user", "content": prompt},
                ],
                max_tokens=1600,
                n=1,
                temperature=0.3
        )

        # Imprimir la respuesta generada
        logger.info("Iniciamos la impresión de las preguntas")

        # Reemplazar el marcador <CURRENT_DATE> por la fecha actual
        current_date = datetime.now().strftime("%Y-%m-%d")
        answer1 = response1.choices[0].message.content
        answer2 = response2.choices[0].message.content.replace("31-12-9999", current_date)
        answer1 = markdown.markdown(answer1, extensions=['extra', 'nl2br'])
        answer2 = markdown.markdown(answer2, extensions=['extra', 'nl2br'])

        
    return render_template_string('''
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>TRUSTWORTHY RAG</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
      margin: 0;
      padding: 0;
    }
    .container {
      max-width: 1000px;
      margin: 50px auto;
      background: #fff;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    h1 {
      text-align: center;
      color: #333;
    }
    form {
      margin-bottom: 30px;
    }
    label {
      font-weight: bold;
    }
    .question-container {
      display: flex;
      align-items: flex-start;
      gap: 10px;
    }
    .question-container textarea {
      flex: 1;
      padding: 10px;
      font-size: 16px;
      border: 1px solid #ccc;
      border-radius: 4px;
      resize: vertical;
    }
    .question-container input[type="submit"] {
      background-color: #5cb85c;
      color: #fff;
      border: none;
      padding: 10px 20px;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
      align-self: center;
    }
    .question-container input[type="submit"]:hover {
      background-color: #4cae4c;
    }
    .answer {
      border-top: 2px solid #eee;
      padding-top: 20px;
      margin-top: 20px;
    }
    .answer h2 {
      color: #333;
    }
    a.logout {
      display: inline-block;
      margin-top: 20px;
      color: #d9534f;
      text-decoration: none;
    }
    a.logout:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>TRUSTWORTHY RAG</h1>
    <form method="post">
      <label for="question">Write your question:</label><br><br>
      <div class="question-container">
        <textarea id="question" name="question" rows="2" maxlength="800">{{ question|default('') }}</textarea>
        <input type="submit" value="Enviar">
      </div>
    </form>
    {% if answer1 %}
      <div class="answer">
        <h2>Standard Answer:</h2>
        <div>{{ answer1|safe }}</div>
      </div>
    {% endif %}
    {% if answer2 %}
      <div class="answer">
        <h2>Trustworthy Answer:</h2>
        <div>{{ answer2|safe }}</div>
      </div>
    {% endif %}
    {% if error %}
      <div class="answer">
        <h2>Error:</h2>
        <p>{{ error }}</p>
      </div>
    {% endif %}
    <a class="logout" href="{{ url_for('logout') }}">Logout</a>
  </div>
</body>
</html>
    ''', question=question, answer1=answer1, answer2=answer2, error=error)

if __name__ == '__main__':
    app.run(debug=True)
